#ifndef LIBADD
#define LIBADD

int add(int, int);

#endif