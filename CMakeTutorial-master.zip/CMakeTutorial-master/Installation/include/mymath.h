#ifndef MYMATH_H
#define MYMATH_H

int add(int, int);
double add(double, double);
#endif